import axios from 'axios';

const baseURL = 'https://jsonplaceholder.typicode.com/users';

export const getStudents = async () => {
  const response = await axios.get(baseURL);
  return response.data;
};

export const addStudent = async (newStudent) => {
  const response = await axios.post(baseURL, newStudent);
  return response.data;
};

export const updateStudent = async (id, updatedStudent) => {
  const response = await axios.put(`${baseURL}/${id}`, updatedStudent);
  return response.data;
};

export const deleteStudent = async (id) => {
  const response = await axios.delete(`${baseURL}/${id}`);
  return response.data;
};

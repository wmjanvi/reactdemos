import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addNewStudent } from './studentSlice';

const StudentForm = () => {
  const dispatch = useDispatch();
  const [newStudent, setNewStudent] = useState({
    name: '',
    email: '',
    password: '',
    rollNo: '',
    gender: '',
    city: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewStudent((prevStudent) => ({ ...prevStudent, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addNewStudent(newStudent));
    // Optionally, clear the form or handle any other actions after submitting
  };

  return (
    <div>
      <h2>Add New Student</h2>
      <form onSubmit={handleSubmit}>
        <label>Name:</label>
        <input type="text" name="name" value={newStudent.name} onChange={handleChange} />
        <br />
        <label>Email:</label>
        <input type="text" name="email" value={newStudent.email} onChange={handleChange} />
        <br />
        <label>Password:</label>
        <input type="password" name="password" value={newStudent.password} onChange={handleChange} />
        <br />
        <label>Roll No:</label>
        <input type="text" name="rollNo" value={newStudent.rollNo} onChange={handleChange} />
        <br />
        <label>Gender:</label>
        <input type="text" name="gender" value={newStudent.gender} onChange={handleChange} />
        <br />
        <label>City:</label>
        <input type="text" name="city" value={newStudent.city} onChange={handleChange} />
        <br />
        <button type="submit">Add Student</button>
      </form>
    </div>
  );
};

export default StudentForm;

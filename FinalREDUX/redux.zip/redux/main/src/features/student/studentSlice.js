import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import * as api from '../../api/studentApi';

export const fetchStudents = createAsyncThunk('students/fetchStudents', api.getStudents);
export const addNewStudent = createAsyncThunk('students/addNewStudent', api.addStudent);
export const updateExistingStudent = createAsyncThunk('students/updateExistingStudent', api.updateStudent);
export const deleteStudentById = createAsyncThunk('students/deleteStudentById', api.deleteStudent);

const studentSlice = createSlice({
  name: 'students',
  initialState: { data: [], status: 'idle', error: null },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchStudents.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchStudents.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.data = action.payload;
      })
      .addCase(fetchStudents.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
      .addCase(addNewStudent.fulfilled, (state, action) => {
        state.data.push(action.payload);
      })
      .addCase(updateExistingStudent.fulfilled, (state, action) => {
        const index = state.data.findIndex((student) => student.id === action.payload.id);
        state.data[index] = action.payload;
      })
      .addCase(deleteStudentById.fulfilled, (state, action) => {
        state.data = state.data.filter((student) => student.id !== action.payload.id);
      });
  },
});

export default studentSlice.reducer;

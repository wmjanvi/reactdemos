import React from 'react';
import { useSelector } from 'react-redux';

const StudentDetail = ({ studentId }) => {
  const student = useSelector((state) =>
    state.students.data.find((student) => student.id === studentId)
  );

  if (!student) {
    return <div>Student not found</div>;
  }

  return (
    <div>
      <h2>Student Details</h2>
      <p>Name: {student.name}</p>
      <p>Email: {student.email}</p>
      <p>Password: {student.password}</p>
      <p>Roll No: {student.rollNo}</p>
      <p>Gender: {student.gender}</p>
      <p>City: {student.city}</p>
    </div>
  );
};

export default StudentDetail;

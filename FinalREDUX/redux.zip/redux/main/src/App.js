import React from 'react';


const App = () => {
  const student = { name: 'John', email: 'john@example.com' };
  const emptyObject = {};
  const nonEmptyObject = { message: 'Hello, World!' };

  return (
    <div>
      {student}
      <p>Name: {student.name}</p>
      <p>Email: {student.email}</p>
      {emptyObject}
      {nonEmptyObject.message}
    </div>

  )
}

export default App;
